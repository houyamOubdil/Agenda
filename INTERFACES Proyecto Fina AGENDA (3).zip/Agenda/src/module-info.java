/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/module-info.java to edit this template
 */

    /*module Agenda {
    requires javafx.swt;
    requires javafx.base;
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires javafx.media;
    requires javafx.swing;
    requires javafx.web;
    requires java.sql;
    opens agenda to javafx.base;

    opens agenda to javafx.graphics;*/
    
    
    
    module agenda {
        exports agenda;
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql; 

    //opens agenda to javafx.fxml;
    
}



